const BASE_URL = 'http://codercba.com:9002/'
const TIME_OUT = 10000

export { BASE_URL, TIME_OUT }
